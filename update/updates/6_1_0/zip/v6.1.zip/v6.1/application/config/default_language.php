<?php

$config['language'] = "english";