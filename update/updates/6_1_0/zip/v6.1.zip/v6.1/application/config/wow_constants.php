<?php 

$config['races'] = lang("races", "wow_constants");
$config['classes'] = lang("classes", "wow_constants");

$config['alliance_races'] = array(1,3,4,7,11);
$config['horde_races'] = array(2,5,6,8,10);